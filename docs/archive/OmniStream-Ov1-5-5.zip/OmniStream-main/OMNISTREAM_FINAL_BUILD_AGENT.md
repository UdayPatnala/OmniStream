<USER_REQUEST>
[OMNISTREAM_FINAL_BUILD_AGENT]
[MODE=AUTONOMOUS_PRODUCT_ENGINEER+ARCHITECT+UIUX_ENGINEER+QA+SECURITY+PERFORMANCE_ENGINEER]
[AUTHORITY=MASTER_PRODUCT_VISION+GUARDIAN_DOCUMENTS]
[OBJECTIVE=BUILD_A_WORKING_PRODUCT_NOT_A_MOCKUP]
[DECISION_MODE=AUTONOMOUS_WHEN_UNSPECIFIED]
[PRIORITY=FUNCTIONALITY>RELIABILITY>SECURITY>PERFORMANCE>UX>VISUAL_POLISH>EXPERIMENTAL_FEATURES]
[STATUS=ACTIVE_BUILD_DIRECTIVE]

==================================================
00.READ_BEFORE_ACTION
==================================================

Before making ANY change:

1.READ ALL FIVE OMNISTREAM GUARDIAN DOCUMENTS.
2.RECALL THE COMPLETE OMNISTREAM PRODUCT MOTIVE,ARCHITECTURE,UX,FEATURES,LIMITATIONS,AND DECISIONS ESTABLISHED DURING THIS PROJECT.
3.INSPECT THE CURRENT PROJECT/REPOSITORY/FILES/DEPENDENCIES/ROUTES/COMPONENTS/SERVICES/STORAGE/MODELS/WORKERS/CONFIGURATION.
4.DO NOT ASSUME THAT PREVIOUS AGENTS' CLAIMS ARE TRUE.
5.VERIFY WHAT ACTUALLY EXISTS.
6.COMPARE IMPLEMENTATION AGAINST THE FIVE GUARDIAN DOCUMENTS.
7.IDENTIFY MISSING,BROKEN,FAKE,DEAD,REDUNDANT,UNSAFE,OR UNNECESSARILY COMPLEX PARTS.
8.THEN PLAN.
9.THEN IMPLEMENT.
10.THEN TEST.
11.THEN VISUALLY INSPECT.
12.THEN PERFORMANCE TEST.
13.THEN SECURITY REVIEW.
14.THEN REGRESSION TEST.
15.ONLY THEN DECLARE THE WORK COMPLETE.

==================================================
01.PRIMARY MISSION
==================================================

BUILD OMNISTREAM AS A REAL,USABLE,STABLE,FREE-FIRST PERSONAL MEDIA PRODUCT.

OMNISTREAM HAS TWO DISTINCT EXPERIENCES:

U-TUBE:
PERSONAL VIDEO DISCOVERY+WATCHING.

CINEMORPH:
THEATER-STYLE INTELLIGENT MEDIA PRESENTATION.

THE TWO EXPERIENCES MUST SHARE INFRASTRUCTURE WHERE BENEFICIAL,BUT MUST HAVE DISTINCT PRODUCT IDENTITIES.

DO NOT BUILD A LARGE DEMO.

BUILD A REAL PRODUCT.

==================================================
02.CORE PRODUCT TEST
==================================================

THE FINAL USER MUST BE ABLE TO:

OPEN OMNISTREAM
â†’CHOOSE U-TUBE OR CINEMORPH
â†’USE THE SELECTED EXPERIENCE
â†’COMPLETE THE CORE TASK
â†’LEAVE
â†’RETURN
â†’CONTINUE.

IF THIS BASIC JOURNEY DOES NOT WORK RELIABLY:

DO NOT PRIORITIZE ADVANCED FEATURES.

==================================================
03.AUTONOMOUS DECISION RULE
==================================================

WHEN A DECISION IS NOT EXPLICITLY DEFINED:

MAKE THE DECISION YOURSELF.

CHOOSE THE OPTION THAT MAXIMIZES:

USER VALUE
+
RELIABILITY
+
PERFORMANCE
+
SECURITY
+
PRIVACY
+
MAINTAINABILITY
+
FREE-FIRST OPERATION.

DO NOT ASK THE USER ABOUT EVERY IMPLEMENTATION DETAIL.

ONLY ESCALATE A DECISION WHEN:

1.IT CAN CAUSE IRREVERSIBLE DATA LOSS.
2.IT REQUIRES A MAJOR PRODUCT-VISION CHANGE.
3.IT REQUIRES A PAID SERVICE THAT WAS NOT PLANNED.
4.IT WOULD VIOLATE SECURITY/LEGAL/PLATFORM CONSTRAINTS.
5.TWO OPTIONS HAVE FUNDAMENTALLY DIFFERENT PRODUCT CONSEQUENCES.

OTHERWISE:

DECIDE,IMPLEMENT,TEST.

==================================================
04.NO BLIND CHANGES
==================================================

BEFORE MODIFYING EXISTING CODE:

INSPECT IT.

UNDERSTAND ITS PURPOSE.

IDENTIFY DEPENDENCIES.

IDENTIFY USERS/CONSUMERS.

IDENTIFY POSSIBLE REGRESSIONS.

THEN MODIFY.

NEVER:

DELETE FIRST
AND
UNDERSTAND LATER.

==================================================
05.NO BLIND REWRITE
==================================================

DO NOT REBUILD THE PROJECT FROM SCRATCH SIMPLY BECAUSE:

THE CURRENT CODE IS IMPERFECT,
ANOTHER ARCHITECTURE LOOKS BETTER,
A NEW FRAMEWORK EXISTS,
OR AN AI MODEL PREFERS ANOTHER APPROACH.

REWRITE ONLY WHEN THE EXISTING ARCHITECTURE CREATES A MEASURABLE BLOCKER.

==================================================
06.PRODUCT MOTIVE
==================================================

U-TUBE EXISTS TO CREATE A SIMPLE PERSONAL VIDEO-DISCOVERY/PLAYBACK EXPERIENCE.

CINEMORPH EXISTS TO CREATE A THEATER-INSPIRED,CINEMATIC MEDIA EXPERIENCE.

THE PRODUCT IS NOT REQUIRED TO REPLICATE:

A COMMERCIAL VIDEO PLATFORM'S ENTIRE ALGORITHM,
SOCIAL NETWORK,
ADVERTISING SYSTEM,
ENTERPRISE INFRASTRUCTURE,
OR PROPRIETARY TECHNOLOGY.

==================================================
07.U-TUBE CORE
==================================================

IMPLEMENT:

HOME
SEARCH
SEARCH RESULTS
WATCH
SUBSCRIPTIONS
SUBSCRIPTION FEED
HISTORY
CONTINUE WATCHING
COLLECTIONS
WATCH LATER
FAVORITES
RECENT SEARCHES
LIGHTWEIGHT RECOMMENDATIONS
MINI PLAYER
SETTINGS.

SEARCH FLOW:

USER QUERY
â†’VALIDATE
â†’LOCAL CACHE CHECK
â†’SUPPORTED PROVIDER SEARCH
â†’NORMALIZE
â†’VALIDATE
â†’RANK
â†’DISPLAY.

==================================================
08.U-TUBE DISCOVERY
==================================================

DISCOVERY SOURCES:

1.DIRECT SEARCH.
2.LOCALLY STORED SUBSCRIPTIONS.
3.LIGHTWEIGHT RELATED DISCOVERY FROM RECENT USER ACTIVITY.

SUBSCRIPTION CONTENT MUST RECEIVE HIGH PRIORITY.

DO NOT BUILD A COMPLEX COMMERCIAL-SCALE RECOMMENDATION ENGINE.

==================================================
09.U-TUBE DATA TRUTH
==================================================

ALL DISPLAYED VIDEO DATA MUST COME FROM:

A REAL PROVIDER,
A VALID LOCAL RECORD,
OR A CLEARLY IDENTIFIED DEVELOPMENT FIXTURE THAT NEVER REACHES PRODUCTION.

NEVER FABRICATE:

VIDEOS
THUMBNAILS
CHANNELS
VIEWS
DURATIONS
HISTORY
SUBSCRIPTIONS
RECOMMENDATIONS
AI RESULTS.

==================================================
10.U-TUBE PLAYBACK
==================================================

USE LEGITIMATE,SUPPORTED EMBEDDED/PROVIDER PLAYBACK MECHANISMS WHERE AVAILABLE.

DO NOT:

BYPASS DRM.
BYPASS PROVIDER SECURITY.
BYPASS ACCESS CONTROLS.
BYPASS CAPTCHA.
BYPASS RATE LIMITS.
CIRCUMVENT EMBEDDING RESTRICTIONS.
EXTRACT PROTECTED MEDIA.

IF A VIDEO CANNOT BE PLAYED:

HANDLE IT HONESTLY.

DO NOT FAKE PLAYBACK.

==================================================
11.U-TUBE PLAYBACK CONTINUITY
==================================================

WATCH PAGE
â†’NAVIGATE
â†’MINI PLAYER
â†’CONTINUE PLAYBACK.

PRESERVE:

CURRENT MEDIA
POSITION
DURATION
PLAYBACK STATE
VOLUME
WHERE TECHNICALLY POSSIBLE.

==================================================
12.U-TUBE HISTORY
==================================================

STORE LOCALLY:

VIDEO IDENTITY
POSITION
DURATION
LAST WATCHED
COMPLETION STATE.

CHECKPOINT PERIODICALLY.

DO NOT WRITE TO STORAGE EVERY FRAME.

==================================================
13.U-TUBE SUBSCRIPTIONS
==================================================

SUBSCRIPTIONS ARE LOCAL USER STATE.

FLOW:

CHANNEL INPUT
â†’VALIDATE
â†’RESOLVE
â†’STORE
â†’FEED REFRESH.

REFRESH MUST BE:

CACHED
RATE-LIMITED
BACKGROUND
FAILURE-TOLERANT.

FAILED REFRESH MUST NOT DELETE VALID EXISTING DATA.

==================================================
14.U-TUBE RECOMMENDATION
==================================================

USE:

RECENT SEARCHES
WATCHED CONTENT
SUBSCRIPTIONS
KEYWORD EXTRACTION
AVAILABLE PROVIDER SEARCH.

OPTIONALLY:

QUERY UNDERSTANDING.

DO NOT USE AN LLM TO INVENT RESULTS.

==================================================
15.CINEMORPH CORE
==================================================

CINEMORPH MUST PRIORITIZE:

LOCAL FILE PLAYBACK.

SECONDARY SOURCE:

SUPPORTED ONLINE VIDEO LINK.

LANDING FLOW:

CINEMORPH
â†’LOCAL FILE OR ONLINE LINK
â†’MEDIA PREPARATION
â†’TICKET
â†’THEATER
â†’WATCH.

==================================================
16.CINEMORPH MODES
==================================================

THREE PRIMARY MODES:

IMAX=1.90:1 DEFAULT.

TRUE_IMAX=1.43:1.

ORIGINAL=SOURCE-NATIVE.

OPTIONAL SIMPLE 4:3 PRESENTATION MAY EXIST WHERE APPROPRIATE.

DO NOT CLAIM THAT SOFTWARE CAN RECOVER SOURCE IMAGE INFORMATION THAT DOES NOT EXIST.

==================================================
17.CINEMORPH THEATER
==================================================

CREATE A REAL INTERACTIVE THEATER PRESENTATION:

BACKGROUND
THEATER STRUCTURE
SEATS
CURTAINS
SCREEN FRAME
SCREEN APERTURE
VIDEO PLANE
AMBIENT EFFECTS
CONTROLS.

THE USER'S DEVICE IS THE PRESENTATION SURFACE.

DO NOT SHOW A FAKE CINEMA SCREEN INSIDE ANOTHER SCREEN.

==================================================
18.SCREEN-BEHIND-HOLE MODEL
==================================================

IMPLEMENT THE CONCEPT:

THEATER FRAME
+
VISIBLE APERTURE
+
VIDEO PLANE BEHIND IT.

THE VIDEO PLANE MAY MOVE/ZOOM UNDER THE APERTURE TO PRODUCE INTELLIGENT FRAMING.

THE APERTURE MUST REMAIN CLEAN.

NO IMAGE LEAK.

NO GAPS.

NO UNINTENDED EDGES.

==================================================
19.CINEMORPH FRAMING
==================================================

POSSIBLE SIGNALS:

FACE DETECTION
OBJECT DETECTION
SALiency
TRACKING
SCENE DETECTION
MOTION
TEXT
SUBTITLES
COMPOSITION
LOOKROOM
HEADROOM
LEADING LINES
GEOMETRY
VISUAL DEPTH
CAMERA MOVEMENT.

THESE ARE HEURISTICS.

THE SYSTEM MUST NOT BLINDLY APPLY THEM.

==================================================
20.FRAME CANDIDATE PIPELINE
==================================================

VIDEO FRAME/WINDOW
â†’DETECTION
â†’TRACKING
â†’CANDIDATE GENERATION
â†’COMPOSITION SCORING
â†’SAFETY CHECK
â†’BEST CANDIDATE
â†’TEMPORAL SMOOTHING
â†’RENDER.

==================================================
21.COMPOSITION RULES
==================================================

CONSIDER:

FRAME-WITHIN-FRAME
LEADING LINES
DIAGONALS
GEOMETRIC SHAPES
LOOKROOM
HEADROOM
VISUAL DEPTH
VANISHING POINTS
SUBJECT DIRECTION
NEGATIVE SPACE
MOTION DIRECTION.

BUT:

CINEMATOGRAPHIC CONTEXT OVERRIDES SIMPLISTIC RULES.

DO NOT FORCE:

CENTERED FACES
LEFT-TO-RIGHT MOVEMENT
STRAIGHT HORIZONS
SYMMETRY

WHEN THE SOURCE CLEARLY INTENDS OTHERWISE.

==================================================
22.SMART FRAMING STABILITY
==================================================

MUST USE:

TEMPORAL SMOOTHING
HYSTERESIS
VELOCITY LIMITS
CONFIDENCE
STALE-RESULT REJECTION
SHOT-BOUNDARY RESET.

AVOID:

JITTER
OSCILLATION
FRAME HUNTING
MICRO-CORRECTIONS
UNNECESSARY ZOOM
ABRUPT MOVEMENT.

==================================================
23.PLAYBACK-FIRST AI
==================================================

AI IS BEST-EFFORT.

PLAYBACK IS REAL-TIME PRIORITY.

IF AI IS SLOW:

REDUCE ANALYSIS.

IF AI FAILS:

USE SAFE FRAME.

IF AI CRASHES:

PLAYBACK CONTINUES.

==================================================
24.ADAPTIVE ANALYSIS
==================================================

DO NOT ANALYZE EVERY FRAME BY DEFAULT.

USE:

SCENE SAMPLING
MOTION-ADAPTIVE ANALYSIS
TRACKING
SHORT LOOKAHEAD
RE-DETECTION WHEN TRACKING FAILS.

3-HOUR MEDIA MUST NEVER REQUIRE:

3 HOURS OF VIDEO
â†’FULL RAM LOAD
â†’FULL FRAME-BY-FRAME PREPROCESSING
BEFORE PLAYBACK.

==================================================
25.LOOKAHEAD
==================================================

WHILE PLAYING T:

PREPARE SMALL FUTURE WINDOW.

DO NOT PROCESS UNLIMITED FUTURE CONTENT.

ANALYSIS QUEUES MUST HAVE BOUNDS.

STALE WORK MUST BE DISCARDED.

==================================================
26.MODEL ROUTER
==================================================

BUILD A MODEL ROUTER THAT CAN SELECT BASED ON:

DEVICE CAPABILITY
CPU
GPU
WEBGPU
MEMORY
CURRENT FPS
THERMAL/RESOURCE PRESSURE
SCENE COMPLEXITY.

POSSIBLE LEVELS:

SAFE
PERFORMANCE
AUTO
CINEMATIC.

==================================================
27.HYBRID AI
==================================================

PREFERRED:

FAST RULES
+
SPECIALIST VISION MODELS
+
TRACKING
+
COMPOSITION ENGINE
+
TEMPORAL FILTER.

DO NOT FORCE AN LLM INTO REAL-TIME VIDEO CONTROL.

==================================================
28.CUSTOM MODELS
==================================================

CUSTOM MODELS ARE OPTIONAL.

ONLY TRAIN ONE IF:

EXISTING MODELS FAIL A MEASURABLE REQUIREMENT.

DEFINE:

DATASET
LABELS
METRICS
LATENCY
MEMORY
FAILURE BEHAVIOR.

==================================================
29.LOCAL LLM
==================================================

A LOCAL LLM MAY BE USED IN FUTURE FOR:

SEARCH INTERPRETATION
MEDIA ORGANIZATION
NATURAL-LANGUAGE COMMANDS
SCENE SEMANTIC ANALYSIS
DEVELOPER PRODUCTIVITY.

IT MUST NOT BECOME A REQUIRED DEPENDENCY FOR BASIC PLAYBACK.

==================================================
30.AUDIO
==================================================

SUPPORT AVAILABLE AUDIO TRACKS.

ALLOW TRACK SWITCHING WHERE TECHNICALLY POSSIBLE.

OPTIONAL ENHANCEMENT:

EQUALIZATION
DIALOGUE ENHANCEMENT
DYNAMIC PROCESSING
SPATIAL EFFECTS WHERE SUPPORTED.

ORIGINAL AUDIO IS ALWAYS THE FALLBACK.

DO NOT CLAIM:

DOLBY
ATMOS
LOSSLESS
THEATER-GRADE

UNLESS THE ACTUAL PLAYBACK CHAIN SUPPORTS IT.

==================================================
31.SUBTITLES
==================================================

SUPPORT AVAILABLE TRACKS WHERE POSSIBLE.

SMART FRAMING MUST PROTECT SUBTITLE AREAS.

==================================================
32.LOCAL FILES
==================================================

USE NATIVE/STREAMING MEDIA HANDLING.

DO NOT LOAD ENTIRE LARGE FILES INTO MEMORY.

SUPPORT AS MANY PRACTICAL BROWSER-DECODED FORMATS AS POSSIBLE.

DETECT ACTUAL CAPABILITY.

DO NOT CLAIM "EVERY FORMAT."

==================================================
33.UNSUPPORTED FILES
==================================================

DISPLAY:

WHAT FAILED
WHY
WHAT USER CAN DO.

DO NOT CRASH.

==================================================
34.TICKET EXPERIENCE
==================================================

TICKET SHOULD DISPLAY REAL SESSION INFORMATION:

TITLE
RUNTIME
THEATER NAME
PRESENTATION MODE
SEAT NUMBER/DECORATIVE SESSION DATA.

TICKET ANIMATION SHOULD BE USED TO CREATE ANTICIPATION WHILE ACTUAL PREPARATION HAPPENS.

DO NOT FAKE PROCESSING.

==================================================
35.CINEMORPH INTRO
==================================================

DEFAULT:

TICKET
â†’CURTAIN
â†’SCREEN REVEAL
â†’SHORT INTRO
â†’MOVIE.

INTRO SHOULD BE SHORT AND NON-INTRUSIVE.

DO NOT DELAY THE USER UNNECESSARILY.

==================================================
36.SESSION RESUME
==================================================

SAVE:

MEDIA IDENTITY
PLAYBACK POSITION
MODE
AUDIO TRACK
SUBTITLE TRACK
SESSION INFORMATION.

IF LOCAL FILE ACCESS CANNOT BE RESTORED:

ASK USER TO RESELECT THE FILE.

DO NOT PRETEND THE FILE STILL EXISTS.

==================================================
37.OFFLINE
==================================================

LOCAL MEDIA SHOULD CONTINUE WORKING WITHOUT INTERNET WHERE BROWSER/MEDIA SUPPORT ALLOWS.

REMOTE MEDIA IS SUBJECT TO PROVIDER/NETWORK AVAILABILITY.

DO NOT CLAIM OFFLINE REMOTE PLAYBACK WITHOUT ACTUAL SUPPORT.

==================================================
38.UI REQUIREMENT
==================================================

U-TUBE:

WHITE
RED
MODERN
CLEAN
VIDEO-FIRST.

CINEMORPH:

PAPER
FILM
THEATER
CURTAIN
TICKET
CAMERA
REEL
POPCORN
WARM CINEMATIC LANGUAGE.

THE TWO MUST FEEL DISTINCT.

==================================================
39.RESPONSIVE DESIGN
==================================================

U-TUBE:

MOBILE
TABLET
DESKTOP.

CINEMORPH:

DESKTOP
LARGE SCREEN
TV-LIKE
ULTRAWIDE.

DO NOT FORCE THE FULL THEATER EXPERIENCE ON MOBILE.

==================================================
40.NO VISUAL MOCKUP
==================================================

EVERY CORE UI CONTROL MUST CONNECT TO REAL FUNCTIONALITY.

NO:

FAKE BUTTON
FAKE PLAYER
FAKE SEARCH
FAKE AI
FAKE DATA
FAKE DOWNLOAD
FAKE SUBSCRIPTION
FAKE PROCESSING
FAKE STATISTICS.

==================================================
41.NO SELF-MERIT
==================================================

NEVER DECLARE:

"PERFECT"
"100% COMPLETE"
"FULLY PRODUCTION READY"
"UNHACKABLE"
"BEST POSSIBLE"

WITHOUT OBJECTIVE VERIFICATION.

==================================================
42.NO FAKE TESTING
==================================================

NEVER CLAIM:

"TEST PASSED"

UNLESS THE TEST WAS ACTUALLY EXECUTED.

==================================================
43.NO FAKE PERFORMANCE
==================================================

NEVER INVENT:

FPS
LATENCY
MEMORY
MODEL ACCURACY
STARTUP TIME
LOAD TIME.

MEASURE THEM.

==================================================
44.NO FAKE FALLBACK
==================================================

A FALLBACK MUST BE A REAL FUNCTIONAL PATH.

==================================================
45.SECURITY
==================================================

TREAT AS UNTRUSTED:

USER INPUT
URLS
PROVIDER RESPONSES
METADATA
SUBTITLES
FILENAMES
LOCAL MEDIA
MODEL FILES.

PROTECT AGAINST:

XSS
INJECTION
MALICIOUS URLS
MALICIOUS SUBTITLES
RESOURCE EXHAUSTION
DEPENDENCY RISKS
SECRET EXPOSURE.

==================================================
46.SECURITY BOUNDARY
==================================================

NEVER:

DISABLE BROWSER SECURITY
EMBED ARBITRARY UNVALIDATED URLS
EXECUTE USER CONTENT
EXPOSE API SECRETS
STORE SECRETS IN FRONTEND
BYPASS DRM
BYPASS ACCESS CONTROLS
BYPASS CAPTCHAS
BYPASS PROVIDER SECURITY.

==================================================
47.PRIVACY
==================================================

PREFER:

LOCAL HISTORY
LOCAL SUBSCRIPTIONS
LOCAL COLLECTIONS
LOCAL TICKETS
LOCAL SETTINGS
LOCAL MEDIA PROCESSING.

DO NOT SEND LOCAL MOVIES TO A SERVER WITHOUT EXPLICIT USER ACTION.

NO HIDDEN TRACKING.

==================================================
48.FREE-FIRST
==================================================

THE CORE PRODUCT SHOULD REMAIN FREE-FIRST.

IF A SERVICE HAS:

QUOTA
LIMIT
COST
DEPENDENCY

DOCUMENT IT.

DO NOT HIDE IT.

WHEN POSSIBLE:

LOCAL
OPEN-SOURCE
FREE
CACHED
DETERMINISTIC

SHOULD BE PREFERRED.

==================================================
49.ARCHITECTURE
==================================================

USE CLEAR LAYERS:

PRESENTATION
APPLICATION
DOMAIN
SERVICES
ADAPTERS
INFRASTRUCTURE.

==================================================
50.SHARED CORE
==================================================

SHARED:

MEDIA IDENTITY
PLAYBACK
STORAGE UTILITIES
SETTINGS
DIAGNOSTICS.

U-TUBE OWNS:

SEARCH
SUBSCRIPTIONS
FEED
HISTORY
COLLECTIONS.

CINEMORPH OWNS:

THEATER
FRAMING
VISION
AUDIO ENHANCEMENT
LOCAL MEDIA EXPERIENCE.

==================================================
51.NO GOD COMPONENT
==================================================

DO NOT CREATE:

ONE GIANT COMPONENT
ONE GIANT SERVICE
ONE GIANT STATE STORE
ONE GIANT MODEL.

==================================================
52.WORKERS
==================================================

HEAVY PROCESSING:

VISION
ANALYSIS
TRANSCODING WHERE REQUIRED
MODEL INFERENCE

SHOULD NOT BLOCK THE MAIN UI THREAD WHERE POSSIBLE.

==================================================
53.WORKER SAFETY
==================================================

EVERY WORKER RESULT MUST BE ASSOCIATED WITH:

SESSION ID
MEDIA ID
TIMESTAMP
MODEL VERSION.

STALE RESULTS MUST BE REJECTED.

==================================================
54.STORAGE
==================================================

USE APPROPRIATE LOCAL STORAGE.

DO NOT STORE LARGE MEDIA IN:

localStorage.

USE STRUCTURED STORAGE/INDEXEDDB/APPROPRIATE FILE APIs WHERE AVAILABLE.

==================================================
55.SCHEMA
==================================================

PERSISTED DATA MUST HAVE:

schemaVersion.

SAFE MIGRATION IS REQUIRED.

==================================================
56.MEMORY
==================================================

CLEAN:

EVENT LISTENERS
TIMERS
WORKERS
OBJECT URLS
VIDEO FRAMES
IMAGE BITMAPS
AUDIO NODES
TEMPORARY BUFFERS.

==================================================
57.PERFORMANCE
==================================================

PRIMARY PRIORITY:

PLAYBACK
â†’AUDIO SYNC
â†’RENDER
â†’INPUT
â†’AI
â†’DECORATION.

==================================================
58.PERFORMANCE ADAPTATION
==================================================

IF FPS DROPS:

REDUCE AI.

IF MEMORY GROWS:

REDUCE CACHE/ANALYSIS.

IF GPU OVERLOADS:

REDUCE INFERENCE/EFFECTS.

IF NETWORK SLOWS:

USE CACHE WHERE VALID.

NEVER SACRIFICE CORE PLAYBACK TO PRESERVE AN ADVANCED EFFECT.

==================================================
59.LOADING
==================================================

USE REAL:

LOADING
PROGRESS
SUCCESS
ERROR
EMPTY.

IF EXACT PROGRESS IS UNKNOWN:

USE INDETERMINATE PROGRESS.

==================================================
60.CACHE
==================================================

CACHE ONLY WHEN BENEFICIAL.

ALL CACHES REQUIRE:

SIZE LIMIT
VERSION
INVALIDATION
CLEANUP.

==================================================
61.REQUEST CONTROL
==================================================

USE:

DEBOUNCE
DEDUPLICATION
ABORT
BACKOFF
BOUNDED CONCURRENCY.

==================================================
62.TESTING
==================================================

TEST:

UNIT
INTEGRATION
E2E
VISUAL
PERFORMANCE
SECURITY
ACCESSIBILITY
MANUAL.

==================================================
63.VULTURE TEST
==================================================

AFTER FUNCTIONAL TESTING:

INSPECT EVERY PAGE VISUALLY.

LOOK FOR:

1PX MISALIGNMENT
WRONG FONT
WRONG SPACING
CLIPPED TEXT
OVERFLOW
Z-INDEX
BROKEN HOVER
BROKEN FOCUS
BAD TRANSITIONS
DEAD BUTTONS
INCONSISTENT ICONS
WRONG RESPONSIVE STATE
UNEXPECTED SCROLLBARS.

==================================================
64.LONG-MOVIE TEST
==================================================

TEST:

30 MIN
1 HOUR
2 HOURS
3 HOURS.

CHECK:

MEMORY
CPU
GPU
AUDIO SYNC
FRAME STABILITY
ANALYSIS QUEUE
PLAYBACK.

==================================================
65.FAILURE TEST
==================================================

DELIBERATELY BREAK:

NETWORK
MODEL
WORKER
AUDIO PROCESSOR
STORAGE
FULLSCREEN
FILE ACCESS
PROVIDER
CODEC.

VERIFY THAT THE APPLICATION FALLS BACK SAFELY.

==================================================
66.CINEMORPH FRAMING TEST
==================================================

TEST:

SINGLE FACE
MULTIPLE FACES
NO FACE
ACTION
DIALOGUE
LANDSCAPE
TEXT
SUBTITLES
CREDITS
DARK SCENES
BRIGHT SCENES
FAST CUTS
CAMERA MOVEMENT
LETTERBOX
MULTIPLE ASPECT RATIOS.

==================================================
67.MODE SWITCH TEST
==================================================

TEST:

1.90
â†’1.43
â†’ORIGINAL
â†’1.90.

VERIFY:

NO POSITION LOSS
NO AUDIO LOSS
NO CRASH
NO JUMP
NO STALE MODEL RESULT.

==================================================
68.SEEK TEST
==================================================

SEEK RAPIDLY.

VERIFY:

OLD ANALYSIS IS CANCELLED/IGNORED.

NEW POSITION GETS CORRECT ANALYSIS.

==================================================
69.AUDIO TEST
==================================================

TEST:

MULTIPLE TRACKS
SWITCH TRACKS
MUTE
VOLUME
LONG PLAYBACK
ENHANCEMENT ON/OFF.

==================================================
70.RESPONSIVE TEST
==================================================

TEST:

SMALL
MEDIUM
LARGE
ULTRAWIDE
FULLSCREEN.

==================================================
71.BROWSER TEST
==================================================

TEST SUPPORTED MAJOR BROWSERS.

DO NOT CLAIM SUPPORT FOR UNTESTED BROWSERS.

==================================================
72.BUILD TEST
==================================================

RUN:

TYPE CHECK
LINT
UNIT TEST
INTEGRATION TEST
PRODUCTION BUILD
E2E WHERE AVAILABLE.

FIX CRITICAL ERRORS.

==================================================
73.CONSOLE TEST
==================================================

PRODUCTION MUST NOT HAVE:

REPEATED ERRORS
UNEXPECTED EXCEPTIONS
SECRET LEAKS
CONTINUOUS WARNING FLOOD.

==================================================
74.NETWORK INSPECTION
==================================================

VERIFY:

NO UNNECESSARY REQUESTS
NO DUPLICATE SEARCHES
NO INFINITE POLLING
NO UNEXPECTED UPLOADS
NO SECRET TRANSMISSION.

==================================================
75.DEAD CODE CLEANUP
==================================================

AFTER IMPLEMENTATION:

REMOVE:

UNUSED IMPORTS
DEAD FUNCTIONS
OBSOLETE COMPONENTS
UNUSED DEPENDENCIES
ABANDONED FLAGS
OLD MOCK DATA
TEMPORARY DEBUG CODE.

BUT:

DO NOT DELETE CODE UNTIL ITS DEPENDENCIES HAVE BEEN VERIFIED.

==================================================
76.DEAD DATA CLEANUP
==================================================

REMOVE OLD:

MOCK DATABASES
FAKE VIDEO DATA
FAKE RECOMMENDATIONS
DEMO STATISTICS
PLACEHOLDER THUMBNAILS.

EXCEPT:

ISOLATED TEST FIXTURES.

==================================================
77.METADATA CLEANUP
==================================================

REMOVE UNWANTED:

AI-GENERATOR REFERENCES
DEVELOPMENT-ONLY AUTHORING METADATA
TEMPORARY PROJECT NAMES
TEST BRANDING
DEBUG INFORMATION.

DO NOT REMOVE LEGITIMATE LICENSE/COPYRIGHT/THIRD-PARTY ATTRIBUTION THAT IS REQUIRED.

==================================================
78.PROJECT IDENTITY
==================================================

PRODUCT NAME:

OMNISTREAM.

EXPERIENCE 1:

U-TUBE.

EXPERIENCE 2:

CINEMORPH.

DO NOT CONFUSE THEM.

==================================================
79.NO UNAUTHORIZED BRAND COPYING
==================================================

U-TUBE MAY BE FAMILIAR AND VIDEO-PLATFORM INSPIRED.

DO NOT COPY PROPRIETARY BRAND ASSETS,TRADE DRESS,OR INTERNAL TECHNOLOGY.

==================================================
80.CINEMORPH IDENTITY
==================================================

CINEMORPH MUST FEEL ORIGINAL:

THEATER
FILM
TICKET
CURTAIN
SCREEN
CINEMATIC PRESENTATION.

==================================================
81.USER EXPERIENCE FINAL CHECK
==================================================

A NON-TECHNICAL USER SHOULD BE ABLE TO:

UNDERSTAND LANDING PAGE.

CHOOSE U-TUBE.

SEARCH.

WATCH.

RETURN.

SUBSCRIBE.

RESUME.

OR:

CHOOSE CINEMORPH.

SELECT LOCAL FILE.

GET TICKET.

ENTER THEATER.

WATCH.

CHANGE MODE.

CHANGE AUDIO.

RESUME.

WITHOUT READING TECHNICAL DOCUMENTATION.

==================================================
82.NO TECHNICAL UI
==================================================

DO NOT EXPOSE TO NORMAL USERS:

MODEL NAMES
WORKER COUNTS
GPU MEMORY
API QUOTAS
INFERENCE FPS
INTERNAL STATE MACHINES
DEBUG IDs.

ADVANCED DIAGNOSTICS MAY EXIST SEPARATELY.

==================================================
83.ADVANCED SETTINGS
==================================================

IF ADVANCED CONTROLS ARE REQUIRED:

PLACE THEM BEHIND AN ADVANCED/EXPERT SECTION.

DEFAULT UX REMAINS SIMPLE.

==================================================
84.FEATURE PRIORITY
==================================================

WHEN TIME/RESOURCES ARE LIMITED:

1.CORE PLAYBACK.
2.SEARCH.
3.LOCAL MEDIA.
4.HISTORY/RESUME.
5.SUBSCRIPTIONS.
6.THEATER.
7.SMART FRAMING.
8.AUDIO ENHANCEMENT.
9.RECOMMENDATIONS.
10.DECORATIVE FEATURES.

==================================================
85.FUTURE FEATURES
==================================================

POSSIBLE FUTURE:

LOCAL LLM
CUSTOM FRAMING MODEL
ADVANCED SEMANTIC SEARCH
CLOUD SYNC
MULTI-DEVICE
MORE PROVIDERS
ADVANCED AUDIO
GENERATIVE FRAME EXPANSION
CUSTOM CINEMA MODES.

DO NOT IMPLEMENT FUTURE FEATURES AUTOMATICALLY UNLESS THEY HAVE BEEN JUSTIFIED.

==================================================
86.GENERATIVE VIDEO BOUNDARY
==================================================

DO NOT GENERATE NEW MOVIE CONTENT AS PART OF NORMAL CINEMORPH FRAMING.

CURRENT OBJECTIVE:

CROP
POSITION
TRACK
PRESENT
ENHANCE.

NOT:

INVENT.

==================================================
87.NO CONTENT ALTERATION
==================================================

DO NOT:

REMOVE CHARACTERS
HIDE CRITICAL OBJECTS
ALTER STORY
REMOVE ATTRIBUTION
ALTER DIALOGUE.

==================================================
88.CINEMATOGRAPHY RESPECT
==================================================

THE SOURCE COMPOSITION IS THE DEFAULT TRUTH.

WHEN SMART FRAMING IS NOT CLEARLY BETTER:

KEEP THE SOURCE.

==================================================
89.USER CONTROL
==================================================

USER MUST BE ABLE TO CHOOSE:

ORIGINAL
IMAX
TRUE IMAX.

WHERE IMPLEMENTED:

AI ON/OFF
PERFORMANCE PROFILE
AUDIO TRACK
SUBTITLE TRACK.

==================================================
90.NO FORCED AI
==================================================

AI SHOULD ENHANCE.

IT MUST NOT CONTROL THE PRODUCT AGAINST USER INTEREST.

==================================================
91.RECOVERY
==================================================

ANY FAILURE SHOULD MOVE DOWN THE FALLBACK TREE:

ADVANCED
â†’SAFE
â†’ORIGINAL.

NEVER:

FAIL
â†’BLANK SCREEN.

==================================================
92.RELEASE CRITERIA
==================================================

DO NOT DECLARE FINAL COMPLETION UNTIL:

[ ]LANDING WORKS
[ ]U-TUBE WORKS
[ ]SEARCH WORKS
[ ]REAL RESULTS WORK
[ ]PLAYBACK WORKS WHERE SUPPORTED
[ ]MINI PLAYER WORKS
[ ]HISTORY WORKS
[ ]RESUME WORKS
[ ]SUBSCRIPTIONS WORK
[ ]FEED WORKS
[ ]COLLECTIONS WORK
[ ]CINEMORPH WORKS
[ ]LOCAL MEDIA WORKS
[ ]TICKET WORKS
[ ]THEATER WORKS
[ ]1.90 WORKS
[ ]1.43 WORKS
[ ]ORIGINAL WORKS
[ ]SMART FRAMING WORKS OR FALLS BACK
[ ]AUDIO WORKS OR FALLS BACK
[ ]SUBTITLES WORK OR FALL BACK
[ ]LONG MEDIA TEST PASSES
[ ]FAILURE TEST PASSES
[ ]SECURITY REVIEW PASSES
[ ]PERFORMANCE REVIEW PASSES
[ ]ACCESSIBILITY REVIEW PASSES
[ ]VISUAL VULTURE REVIEW PASSES
[ ]DEAD CODE CLEANED
[ ]DEAD MOCK DATA CLEANED
[ ]DOCUMENTATION UPDATED
[ ]PRODUCTION BUILD PASSES
[ ]NO CRITICAL CONSOLE ERRORS
[ ]NO FALSE FEATURE CLAIMS.

==================================================
93.COMPLETION DEFINITION
==================================================

"COMPLETE" MEANS:

THE PRODUCT CAN BE USED.

NOT:

THE PRODUCT HAS MANY FILES.

NOT:

THE PRODUCT LOOKS GOOD IN A SCREENSHOT.

NOT:

THE AGENT GENERATED A LARGE AMOUNT OF CODE.

NOT:

THE AGENT SAYS IT IS COMPLETE.

==================================================
94.FINAL VULTURE PASS
==================================================

BEFORE FINAL DECLARATION:

OPEN EVERY ROUTE.

CLICK EVERY CORE BUTTON.

TEST EVERY CORE FLOW.

TRY INVALID INPUT.

TRY EMPTY STATE.

TRY NETWORK FAILURE.

TRY REFRESH.

TRY BACK BUTTON.

TRY FULLSCREEN.

TRY LONG PLAYBACK.

TRY MODE SWITCH.

TRY AUDIO SWITCH.

TRY SUBTITLE SWITCH.

TRY RESUME.

TRY REPEATED OPEN/CLOSE.

TRY MULTIPLE SESSIONS.

INSPECT CONSOLE.

INSPECT NETWORK.

INSPECT MEMORY.

INSPECT RESPONSIVENESS.

INSPECT VISUAL DETAILS.

FIX EVERYTHING THAT SHOULD BE FIXED.

==================================================
95.DO NOT STOP AT "WORKS"
==================================================

AFTER FUNCTIONALITY WORKS:

ASK:

CAN IT BE FASTER?

CAN IT BE SIMPLER?

CAN IT BE SAFER?

CAN IT BE MORE RELIABLE?

CAN IT BE LESS RESOURCE-HUNGRY?

CAN THE UX BE CLEARER?

CAN UNNECESSARY CODE BE REMOVED?

CAN FAILURES BE HANDLED BETTER?

ONLY MAKE CHANGES WHEN THEY ACTUALLY IMPROVE THE PRODUCT.

==================================================
96.DO NOT OVER-OPTIMIZE
==================================================

DO NOT CHANGE WORKING SYSTEMS WITHOUT EVIDENCE.

MEASURE BEFORE/AFTER WHERE PRACTICAL.

==================================================
97.DO NOT OVERENGINEER
==================================================

THE CURRENT PRODUCT IS PERSONAL.

PREFER:

MODULAR MONOLITH
LOCAL STORAGE
LOCAL PROCESSING
WORKERS
ADAPTERS
SMALL SERVICES.

DO NOT INTRODUCE:

MICROSERVICES
KUBERNETES
DISTRIBUTED DATABASES
COMPLEX CLOUD INFRASTRUCTURE

WITHOUT A REAL REQUIREMENT.

==================================================
98.FINAL PRODUCT INTEGRITY
==================================================

IF A FEATURE CANNOT WORK RELIABLY:

MAKE IT OPTIONAL.

IF IT CANNOT WORK AT ALL:

REMOVE IT.

IF IT REQUIRES A PAID SERVICE:

FIND A FREE/LOCAL ALTERNATIVE IF PRACTICAL.

IF NO ALTERNATIVE EXISTS:

DOCUMENT THE LIMITATION.

IF A PROVIDER RESTRICTS SOMETHING:

RESPECT THE RESTRICTION.

IF AI IS TOO EXPENSIVE:

REDUCE AI.

IF THEATER EFFECTS HURT PERFORMANCE:

REDUCE EFFECTS.

IF SMART FRAMING HURTS COMPOSITION:

USE ORIGINAL.

==================================================
99.FINAL AGENT BEHAVIOR
==================================================

ACT LIKE:

A SENIOR SOFTWARE ENGINEER
+
PRODUCT ARCHITECT
+
MEDIA ENGINEER
+
COMPUTER-VISION ENGINEER
+
UI/UX ENGINEER
+
SECURITY ENGINEER
+
PERFORMANCE ENGINEER
+
QA ENGINEER.

DO NOT ACT LIKE:

A CODE GENERATOR THAT ONLY PRODUCES FILES.

==================================================
100.FINAL COMMAND
==================================================

BUILD OMNISTREAM.

DO NOT MERELY DESCRIBE IT.

DO NOT MERELY MOCK IT.

DO NOT MERELY STYLE IT.

DO NOT MERELY ADD FEATURES.

INSPECT THE EXISTING PRODUCT.

UNDERSTAND IT.

COMPARE IT AGAINST THE FIVE GUARDIAN DOCUMENTS.

PRESERVE WHAT WORKS.

REPAIR WHAT IS BROKEN.

REMOVE WHAT IS FAKE.

REMOVE WHAT IS DEAD.

SIMPLIFY WHAT IS UNNECESSARILY COMPLEX.

ADD WHAT IS GENUINELY MISSING.

BUILD REAL FUNCTIONAL FLOWS.

CONNECT EVERY CORE UI CONTROL TO REAL BEHAVIOR.

USE REAL DATA WHERE REQUIRED.

USE REAL FALLBACKS.

USE REAL MODEL INFERENCE WHERE JUSTIFIED.

KEEP HEAVY PROCESSING OFF THE MAIN THREAD WHERE POSSIBLE.

PROTECT PLAYBACK ABOVE ALL OPTIONAL INTELLIGENCE.

PROTECT USER DATA.

PROTECT SECRETS.

RESPECT PROVIDER AND BROWSER SECURITY BOUNDARIES.

MEASURE PERFORMANCE.

TEST FAILURE MODES.

TEST LONG SESSIONS.

TEST LARGE LOCAL MEDIA.

TEST BOTH U-TUBE AND CINEMORPH.

PERFORM A FULL VISUAL VULTURE REVIEW.

PERFORM A SECURITY REVIEW.

PERFORM A PERFORMANCE REVIEW.

PERFORM A DEAD-CODE/DEAD-DATA REVIEW.

PERFORM A FINAL PRODUCT-MOTIVE REVIEW.

THEN:

BUILD
â†’TEST
â†’FIX
â†’RETEST
â†’POLISH
â†’VERIFY
â†’RELEASE.

FINAL SUCCESS CONDITION:

A USER CAN OPEN OMNISTREAM WITHOUT TECHNICAL KNOWLEDGE AND NATURALLY EXPERIENCE:

U-TUBE:
SEARCH â†’ DISCOVER â†’ WATCH â†’ SUBSCRIBE â†’ RETURN â†’ RESUME.

CINEMORPH:
SELECT MEDIA â†’ RECEIVE TICKET â†’ ENTER THEATER â†’ WATCH â†’ EXPERIENCE INTELLIGENT CINEMATIC PRESENTATION â†’ EXIT â†’ RESUME.

THE PRODUCT MUST FEEL SIMPLE.

THE ENGINEERING MUST BE DISCIPLINED.

THE AI MUST BE INVISIBLE WHEN IT WORKS.

THE FALLBACK MUST BE INVISIBLE WHEN POSSIBLE.

THE MOVIE MUST REMAIN THE MOVIE.

THE USER MUST REMAIN IN CONTROL.

DO NOT STOP BECAUSE THE UI LOOKS FINISHED.

STOP ONLY WHEN THE PRODUCT HAS BEEN VERIFIED AS FUNCTIONAL,STABLE,SECURE,PERFORMANT,COHERENT,AND HONEST ABOUT ITS LIMITATIONS.

[END_OMNISTREAM_FINAL_BUILD_AGENT]
</USER_REQUEST>
<ADDITIONAL_METADATA>
The current local time is: 2026-08-24T09:32:54+05:30.
</ADDITIONAL_METADATA>