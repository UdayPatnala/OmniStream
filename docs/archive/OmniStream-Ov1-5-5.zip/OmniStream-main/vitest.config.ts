import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: ['./src/tests/setup.ts'],
    include: [
      'src/tests/**/*.test.ts',
      'src/tests/**/*.test.tsx',
      'src/test/**/*.test.ts',
      'src/test/**/*.test.tsx',
    ],
    testTimeout: 15000,
  },
});
